!pip install openai --quiet

import openai
import getpass

chat_history = [
    {"role": "system", "content": "You are SupportBot, a helpful and friendly customer service assistant. You help users with orders, product info, returns, and troubleshooting issues."}
]

print("🤖 SupportBot is online! Type 'exit' to end the chat.\n")
while True:
    user_input = input("You: ")

    if user_input.lower() in ['exit', 'quit']:
        print("SupportBot: Thanks for reaching out! Have a great day 😊")
        break
    elif user_input.lower() in ['where is my order','what about my order']:
        print("SupportBot: your order is shiping now 🚢🚢 ")
        break
    elif user_input.lower() in ['what you can do']:
        print("SupportBot: I can help you with order you placed it 💥")
        break
    elif user_input.lower() in ['hii','hello']:
        print("SupportBot: hii nice to meet you , what i can do for you sir 🙏🏻🙏🏻")
        break

          # Add user input to history
    chat_history.append({"role": "user", "content": user_input})

    try:
        # Send chat history to OpenAI
        response = openai.ChatCompletion.create(
            model="gpt-3.5-turbo",
            messages=chat_history
        )

        # Get the bot's reply
        reply = response['choices'][0]['message']['content'].strip()
        print(f"SupportBot: {reply}\n")

        # Add bot reply to history
        chat_history.append({"role": "assistant", "content": reply})

    except Exception as e:
        print(f"⚠️ Error: {e}")
        break